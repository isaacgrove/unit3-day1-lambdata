print('Hello World.')

from my_lambdata.my_mod import enlarge 

x = 100

print('x: ', x)
print('Enlarged x: ', enlarge(x))