# my_lambdata/my_mod.py

# Someone's gonna want to pull this function out of here.
# Check my_script.py
def enlarge(n):
    '''
    Param n is a number.
    Function will enlarge the number.
    '''
    return n * 100

