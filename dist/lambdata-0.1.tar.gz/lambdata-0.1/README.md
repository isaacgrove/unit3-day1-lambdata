# unit3-day1-lambdata


## USING THE PACKAGE FORM PYPI INSTRUCTIONS

'''py
from my_lambdata.my_mod import enlarge

enlarge(5) #> 500
<hr>
'''

## INSTALLATION
'''sh
cd path/to/unit3-day1-etc
'''


Install package dependencies

'''sh
pipenv install
'''

## USAGE
'''sh
python my_lambdata/my_script.py
'''